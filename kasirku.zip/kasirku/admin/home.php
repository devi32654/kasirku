<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Link ke CSS Bootstrap (pastikan Bootstrap sudah terhubung dengan benar) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Tambahkan font Awesome untuk ikon -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* Styling untuk card di dashboard */
        .card {
            border-radius: 10px; /* Membuat sudut card menjadi melengkung */
            padding: 20px; /* Menambah padding untuk isi card, lebih kecil */
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Efek transisi */
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15); /* Bayangan halus */
        }

        .card:hover {
            transform: scale(1.03); /* Membuat efek zoom in saat hover */
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.2); /* Membuat bayangan lebih jelas saat hover */
        }

        .card-body {
            font-size: 18px; /* Membuat font lebih kecil dan lebih seimbang */
        }

        .card-body i {
            font-size: 40px; /* Ukuran ikon sedikit lebih kecil */
        }

        .icon-size {
            font-size: 2.5rem; /* Ukuran ikon lebih kecil, proporsional */
        }

        .card-body {
            padding: 15px; /* Padding untuk teks di dalam card, lebih kecil */
        }
    </style>
</head>
<body>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <div class="row">
            <!-- Card Pelanggan -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4 shadow-lg">
                    <div class="card-body text-center">
                        <i class="fas fa-users icon-size"></i> 
                        <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT*FROM pelanggan")); ?> PELANGGAN
                    </div>
                </div>
            </div>

            <!-- Card Produk -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-warning text-white mb-4 shadow-lg">
                    <div class="card-body text-center">
                        <i class="fas fa-box icon-size"></i> 
                        <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT*FROM produk")); ?> PRODUK
                    </div>
                </div>
            </div>

            <!-- Card Pembelian -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-success text-white mb-4 shadow-lg">
                    <div class="card-body text-center">
                        <i class="fas fa-shopping-cart icon-size"></i> 
                        <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT*FROM transaksi")); ?> PEMBELIAN
                    </div>
                </div>
            </div>

            <!-- Card User -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-danger text-white mb-4 shadow-lg">
                    <div class="card-body text-center">
                        <i class="fas fa-user icon-size"></i> 
                        <?php echo mysqli_num_rows(mysqli_query($conn, "SELECT*FROM users")); ?> USER
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
