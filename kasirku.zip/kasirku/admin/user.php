<?php
include 'koneksi.php';

// Proses hapus data user
if (isset($_GET['delete'])) {
    $id_user = $_GET['delete'];

    $query = "DELETE FROM users WHERE id = '$id_user'";

    if (mysqli_query($conn, $query)) {
        echo "<script>
                alert('User berhasil dihapus!');
                window.location.href='?page=user'; 
              </script>";
    } else {
        echo "<script>
                alert('User gagal dihapus. Error: " . mysqli_error($conn) . "');
              </script>";
    }
}

// Menampilkan data user
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <title>Daftar User</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .custom-container {
            margin-top: 20px;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .search-box {
            display: flex;
            align-items: center;
        }
        .search-box input {
            margin-left: 10px;
            width: 200px;
        }
        .icon {
            font-size: 1.5rem;
            margin-right: 10px;
        }
        /* Mengatur lebar kolom agar tidak terlalu lebar dan lebih rapi */
        table {
            table-layout: auto; /* Mengatur lebar kolom secara otomatis sesuai konten */
        }
        th, td {
            padding: 8px; /* Memberikan padding untuk jarak antar teks dan batas sel */
        }
        th {
            text-align: center; /* Menyusun judul kolom di tengah */
        }
        td {
            text-align: left; /* Menyusun isi kolom ke kiri untuk kolom lainnya */
        }
        td:nth-child(1) {
            width: 2%; /* Lebar kolom No */
        }
        td:nth-child(2) {
            width: 10%; /* Lebar kolom Password */
        }
        td:nth-child(3) {
            width: 10%; /* Lebar kolom Username */
        }
        td:nth-child(4) {
            width: 10%; /* Lebar kolom Role */
        }
        td:nth-child(5) {
            width: 5%; /* Lebar kolom Aksi */
        }

        .custom-btn {
            background-color:rgb(0, 0, 0);  /* Warna latar belakang tombol */
            color: rgb(255, 255, 255);               /* Warna ikon putih */
            width: 45px;                /* Ukuran tombol */
            height: 45px;               /* Ukuran tombol */
            display: flex;              /* Agar ikon berada di tengah */
            justify-content: center;    /* Menyusun ikon di tengah secara horizontal */
            align-items: center;        /* Menyusun ikon di tengah secara vertikal */
            border: none;               /* Menghapus border default */
            font-size: 30px;            /* Ukuran ikon */
            border-radius: 50%;         /* Membuat tombol berbentuk bulat */
            box-sizing: border-box;     /* Pastikan ukuran tombol pas */
        }

        .custom-btn:hover {
            background-color:rgb(255, 255, 255);  /* Warna latar belakang tombol saat hover */
        }
    </style>
</head>
<body>

<div class="container-fluid px-4 custom-container">
    <div class="card">
        <div class="card-header">
            <div class="search-box">
                <span class="icon"><i class="fas fa-user"></i></span> <!-- Ikon user -->
                <input type="text" class="form-control" id="search" placeholder="Cari user...">
            </div>
            <!-- Tombol add user dengan ikon custom dan bentuk bulat -->
            <a href="?page=add_user" class="custom-btn"><i class="bi bi-plus"></i></a>
        </div>
        <div class="card-body">
            <!-- Tabel Daftar User -->
            <table class="table table-bordered table-hover">
            <thead style="background-color:rgb(0, 0, 0); color: white;">
                    <tr>
                        <th>No</th>
                        <th>Password</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="userTable">
                    <?php
                    if ($result) {
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                    <td>{$no}</td>
                                    <td>{$row['password']}</td>
                                    <td>{$row['username']}</td>
                                    <td>{$row['role']}</td>
                                   <td>
                                    <a href='?page=edit_user&id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='?page=user&delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah Anda yakin ingin menghapus user ini?\")'>Hapus</a>
                                </td>

                                  </tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='5'>Error: " . mysqli_error($conn) . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Filter untuk pencarian user
    document.getElementById('search').addEventListener('keyup', function () {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll('#userTable tr');
        
        rows.forEach(row => {
            let username = row.cells[2].textContent.toLowerCase(); // Disesuaikan dengan kolom username yang baru
            if (username.includes(filter)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>
