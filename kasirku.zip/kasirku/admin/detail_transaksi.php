<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id_transaksi = $_GET['id'];

// Ambil data transaksi beserta nama pelanggan
$sql = "
    SELECT t.id_transaksi, t.tanggal_transaksi, t.total_harga, t.bayar, t.kembalian, 
           p.nama_pelanggan, p.alamat, p.no_telepon
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    WHERE t.id_transaksi = $id_transaksi
";
$transaksi = $conn->query($sql)->fetch_assoc();


// Ambil data detail transaksi
$sql = "
    SELECT dt.jumlah, dt.sub_total, pr.nama_produk, pr.harga
    FROM detail_transaksi dt
    JOIN produk pr ON dt.id_produk = pr.id_produk
    WHERE dt.id_transaksi = $id_transaksi
";
$detail_transaksi = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi</title>
    <!-- Link ke Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border: 1px solid #e1e4e8;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-back {
            background-color: #007bff;
            color: white;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card p-4">
            <h1 class="mb-4 text-center">Detail Transaksi</h1>

            <div class="mb-4">
            <div class="mb-4">
    <h3>Informasi Transaksi</h3>
    <div class="row">
        <div class="col-md-6">
            <div class="mb-2"><strong>Tanggal:</strong> <?= $transaksi['tanggal_transaksi'] ?></div>
            <div class="mb-2"><strong>Nama Pelanggan:</strong> <?= $transaksi['nama_pelanggan'] ?></div>
            <div class="mb-2"><strong>Alamat:</strong> <?= $transaksi['alamat'] ?></div>
            <div class="mb-2"><strong>No Telepon:</strong> <?= $transaksi['no_telepon'] ?></div>
            <div class="mb-2"><strong>Total Harga:</strong> Rp <?= number_format($transaksi['total_harga'], 0, ',', '.') ?></div>
<div class="mb-2"><strong>Bayar:</strong> Rp <?= number_format($transaksi['bayar'], 0, ',', '.') ?></div>
<div class="mb-2"><strong>Kembalian:</strong> Rp <?= number_format($transaksi['kembalian'], 0, ',', '.') ?></div>

        </div>
    </div>
</div>


            <div class="mb-4">
                <h3>Detail Produk</h3>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Sub Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($detail_transaksi->num_rows > 0) {
                                while ($row = $detail_transaksi->fetch_assoc()) {
                                    echo "<tr>
                                            <td>" . $row['nama_produk'] . "</td>
                                            <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                                            <td>" . $row['jumlah'] . "</td>
                                            <td>Rp " . number_format($row['sub_total'], 0, ',', '.') . "</td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' class='text-center'>Tidak ada detail transaksi.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="text-center">
                <a href="?page=transaksi" class="btn btn-back">Kembali</a>
            </div>
        </div>
    </div>

    <!-- Link ke Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
