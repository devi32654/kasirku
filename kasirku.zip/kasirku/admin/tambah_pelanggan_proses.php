<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses penyimpanan data pelanggan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    $query = "INSERT INTO pelanggan (nama_pelanggan, alamat, no_telepon) VALUES ('$nama_pelanggan', '$alamat', '$no_telepon')";
    
    if ($conn->query($query) === TRUE) {
        // Redirect ke halaman index.php dengan query string untuk membuka halaman pelanggan
        header("Location: index.php?page=pelanggan");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>
