<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses hapus jika ID ada dalam URL
if (isset($_GET['id'])) {
    $id_pelanggan = $_GET['id'];

    // Query untuk menghapus data pelanggan berdasarkan ID
    $query = "DELETE FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'";

    if ($conn->query($query) === TRUE) {
        // Jika penghapusan berhasil, arahkan kembali ke halaman daftar pelanggan
        echo "<script>alert('Data berhasil dihapus'); window.location.href='index.php?page=pelanggan';</script>";
        exit();
    } else {
        echo "Terjadi kesalahan: " . $conn->error;
    }
}

// Query untuk mengambil semua data pelanggan
$query = "SELECT * FROM pelanggan";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pelanggan</title>
    <!-- Link Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome untuk ikon -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Judul yang diperkecil dan diletakkan di sebelah kiri -->
        <h3 class="mb-4 text-start ms-3">Daftar Pelanggan</h3>

        <!-- Tombol untuk membuka Modal -->
        <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#tambahPelangganModal">
            <i class="fas fa-plus"></i> Tambah Pelanggan
        </button>

        <!-- Tabel Daftar Pelanggan -->
        <div class="card shadow-lg p-4">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Alamat</th>
                        <th>No Telepon</th>
                        <th>Aksi</th> <!-- Menambahkan kolom Aksi -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$no}</td>
                            <td>{$row['nama_pelanggan']}</td>
                            <td>{$row['alamat']}</td>
                            <td>{$row['no_telepon']}</td>
                            <td>
                                <!-- Tombol Edit -->
                                <a href='edit_pelanggan.php?id={$row['id_pelanggan']}' class='btn btn-warning btn-sm'>
                                    <i class='fas fa-edit'></i>
                                </a>
                                <!-- Tombol Hapus -->
                                <a href='?id={$row['id_pelanggan']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin ingin menghapus?\")'>
                                    <i class='fas fa-trash'></i>
                                </a>
                            </td>
                        </tr>";
                        $no++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Pelanggan -->
    <div class="modal fade" id="tambahPelangganModal" tabindex="-1" aria-labelledby="tambahPelangganModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tambahPelangganModalLabel">Tambah Pelanggan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Tambah Pelanggan -->
                    <form action="tambah_pelanggan_proses.php" method="post">
                        <div class="mb-3">
                            <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" required>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" name="alamat" id="alamat" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="no_telepon" class="form-label">No Telepon</label>
                            <input type="text" class="form-control" name="no_telepon" id="no_telepon" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    

    <!-- Link Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
