<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengecek apakah ada ID produk yang diberikan di URL
if (isset($_GET['id'])) {
    $id_produk = $_GET['id'];

    // Query untuk menghapus produk berdasarkan ID
    $sql = "DELETE FROM produk WHERE id_produk = ?";

    // Menggunakan prepared statement untuk mencegah SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_produk);

    // Mengeksekusi query
    if ($stmt->execute()) {
        // Redirect ke halaman daftar produk setelah berhasil menghapus
        header("Location: index.php?page=produk"); // Ganti dengan halaman daftar produk Anda
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    // Jika tidak ada ID produk, arahkan ke halaman daftar produk
    header("Location: produk.php"); // Ganti dengan halaman daftar produk Anda
    exit();
}

// Menutup koneksi
$conn->close();
?>
