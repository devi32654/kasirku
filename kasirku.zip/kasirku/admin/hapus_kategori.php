<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengecek apakah ada ID kategori di URL
if (isset($_GET['id'])) {
    $id_kategori = $_GET['id'];

    // Query untuk menghapus kategori berdasarkan ID
    $sql_delete = "DELETE FROM kategori WHERE id_kategori = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("i", $id_kategori);

    // Eksekusi query penghapusan
    if ($stmt->execute()) {
        // Redirect ke halaman index.php setelah berhasil dihapus
        header("Location: index.php?page=kategori"); // Ganti dengan URL yang sesuai
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    echo "ID kategori tidak ada.";
}

// Menutup koneksi
$conn->close();
?>
