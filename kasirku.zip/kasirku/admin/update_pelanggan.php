<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengecek jika ada data yang dikirimkan melalui form
if (isset($_POST['id_pelanggan'], $_POST['nama_pelanggan'], $_POST['alamat'], $_POST['no_telepon'])) {
    $id_pelanggan = $_POST['id_pelanggan'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    // Query untuk update data pelanggan
    $sql = "UPDATE pelanggan 
            SET nama_pelanggan = '$nama_pelanggan', alamat = '$alamat', no_telepon = '$no_telepon'
            WHERE id_pelanggan = $id_pelanggan";

    if ($conn->query($sql) === TRUE) {
        // Redirect setelah berhasil
        header("Location: pelanggan.php"); // Ganti dengan halaman yang sesuai
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Data tidak lengkap!";
}

// Menutup koneksi
$conn->close();
?>
s