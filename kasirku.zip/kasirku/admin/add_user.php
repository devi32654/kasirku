<?php
include 'koneksi.php';

// Proses simpan data petugas atau admin
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password']; // Menghapus enkripsi password
    $role = $_POST['role']; // Mengambil role dari form (admin atau petugas)

    // Query untuk menambahkan user dengan role yang dipilih
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";

    if (mysqli_query($conn, $query)) {
        echo "<script>
                alert('User berhasil ditambahkan!');
                window.location.href='?page=user'; 
              </script>";
    } else {
        echo "<script>
                alert('User gagal ditambahkan. Error: " . mysqli_error($conn) . "');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Tambah User</title>
</head>
<body>
<div class="container mt-5">
    <h2>Tambah User</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="role" class="form-label">Role</label>
            <select class="form-select" id="role" name="role" required>
                <option value="petugas">Petugas</option>
                <option value="admin">Admin</option>
            </select>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
        <a href="?page=user" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
