<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Transaksi.xls");

$conn = new mysqli('localhost', 'root', '', 'db_kasir');
$sql = "
    SELECT t.tanggal_transaksi, t.total_harga, p.nama_pelanggan
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
";
$result = $conn->query($sql);

echo "<table border='1'>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Transaksi</th>
                <th>Nama Pelanggan</th>
                <th>Total Harga</th>
            </tr>
        </thead>
        <tbody>";
$no = 1;
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $no++ . "</td>
            <td>" . $row['tanggal_transaksi'] . "</td>
            <td>" . $row['nama_pelanggan'] . "</td>
            <td>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>
          </tr>";
}
echo "</tbody></table>";
?>
