<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ada ID pelanggan yang diberikan
if (isset($_GET['id'])) {
    $id_pelanggan = $_GET['id'];

    // Query untuk mendapatkan data pelanggan berdasarkan ID
    $query = "SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();

    if (!$row) {
        die("Pelanggan tidak ditemukan.");
    }
} else {
    // Jika tidak ada ID pelanggan, arahkan kembali ke daftar pelanggan
    header("Location: index.php"); // Ganti dengan halaman daftar pelanggan Anda
    exit();
}

// Proses update jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pelanggan = $_POST['id_pelanggan'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    // Query untuk update data pelanggan
    $query = "UPDATE pelanggan SET nama_pelanggan = '$nama_pelanggan', alamat = '$alamat', no_telepon = '$no_telepon' WHERE id_pelanggan = '$id_pelanggan'";

    if ($conn->query($query) === TRUE) {
        // Arahkan ke halaman daftar pelanggan setelah berhasil update
        header("Location: index.php?page=pelanggan"); // Ganti dengan URL daftar pelanggan yang sesuai
        exit();
    } else {
        echo "<script>alert('Terjadi kesalahan: " . $conn->error . "');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="border p-4 bg-light rounded"> <!-- Membungkus seluruh form dalam box -->
            <h3 class="mb-4">Edit Pelanggan</h3>

            <!-- Form Edit Pelanggan -->
            <form action="" method="post">
                <input type="hidden" name="id_pelanggan" value="<?php echo $row['id_pelanggan']; ?>">

                <div class="mb-3">
                    <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                    <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" value="<?php echo $row['nama_pelanggan']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control" name="alamat" id="alamat" rows="3" required><?php echo $row['alamat']; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="no_telepon" class="form-label">No Telepon</label>
                    <input type="text" class="form-control" name="no_telepon" id="no_telepon" value="<?php echo $row['no_telepon']; ?>" required>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan
                </button>
                <a href="index.php?page=pelanggan" class="btn btn-secondary">Kembali</a>
            </form>
        </div> <!-- Akhir box -->
    </div>

    <!-- Link Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
