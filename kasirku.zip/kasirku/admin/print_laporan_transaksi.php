<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Filter tanggal (jika ada)
$filter = '';
if (isset($_POST['filter'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $filter = "WHERE t.tanggal_transaksi BETWEEN '$start_date' AND '$end_date'";
}

// Ambil data transaksi dengan detail produk
$sql = "
    SELECT t.id_transaksi, t.tanggal_transaksi, t.total_harga, t.bayar, t.kembalian, 
           p.nama_pelanggan, pr.nama_produk
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    JOIN detail_transaksi dt ON t.id_transaksi = dt.id_transaksi
    JOIN produk pr ON dt.id_produk = pr.id_produk
    $filter
    ORDER BY t.tanggal_transaksi DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 20px;
            }
            .table th, .table td {
                border: 1px solid black !important;
                padding: 8px;
            }
        }

        body {
            background-color: white;
            color: black;
        }
        .table th, .table td {
            text-align: left;
        }
    </style>
</head>
<body onload="window.print()"> <!-- Auto Print -->
    <div class="container mt-4">
        <h2 class="text-center">Laporan Transaksi</h2>
        <p class="text-center">Tanggal Cetak: <?php echo date('d-m-Y'); ?></p>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Tanggal Transaksi</th>
                    <th>Nama Pelanggan</th>
                    <th>Nama Produk</th>
                    <th>Total Harga</th>
                    <th>Total Bayar</th>
                    <th>Kembalian</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $no++ . "</td>
                                <td>" . $row['tanggal_transaksi'] . "</td>
                                <td>" . $row['nama_pelanggan'] . "</td>
                                <td>" . $row['nama_produk'] . "</td>
                                <td>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>
                                <td>Rp " . number_format($row['bayar'], 0, ',', '.') . "</td>
                                <td>Rp " . number_format($row['kembalian'], 0, ',', '.') . "</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>Tidak ada data transaksi.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
