<?php
// Koneksi ke database 'db_kasir'
$conn = new mysqli('localhost', 'root', '', 'db_kasir');

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengecek apakah ada ID produk di URL
if (isset($_GET['id'])) {
    $id_produk = $_GET['id'];

    // Query untuk mengambil data produk berdasarkan ID
    $sql = "SELECT produk.*, kategori.nama_kategori 
            FROM produk 
            JOIN kategori ON produk.id_kategori = kategori.id_kategori
            WHERE produk.id_produk = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_produk);
    $stmt->execute();
    $result = $stmt->get_result();

    // Cek apakah produk ditemukan
    if ($result->num_rows == 0) {
        echo "Produk tidak ditemukan.";
        exit;
    }

    // Ambil data produk
    $row = $result->fetch_assoc();
} else {
    echo "ID produk tidak ada.";
    exit;
}

// Menangani form submission untuk update produk
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $nama_produk = $_POST['nama_produk'];
    $id_kategori = $_POST['id_kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Query untuk update data produk
    $sql_update = "UPDATE produk SET nama_produk = ?, id_kategori = ?, harga = ?, stok = ? WHERE id_produk = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sdiis", $nama_produk, $id_kategori, $harga, $stok, $id_produk);

    // Eksekusi query
    if ($stmt_update->execute()) {
        // Redirect setelah sukses update
        header("Location:index.php?page=produk");
        exit();
    } else {
        echo "Error: " . $stmt_update->error;
    }
}

// Menutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <!-- Link ke Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card p-4">
            <h3 class="mb-4">Edit Produk</h3>
            <form action="edit_produk.php?id=<?php echo $id_produk; ?>" method="POST">
                <div class="mb-3">
                    <label for="nama_produk" class="form-label">Nama Produk</label>
                    <input type="text" class="form-control" name="nama_produk" id="nama_produk" value="<?php echo $row['nama_produk']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="id_kategori" class="form-label">Kategori</label>
                    <select class="form-select" name="id_kategori" id="id_kategori" required>
                        <?php
                        // Koneksi database
                        $conn = new mysqli('localhost', 'root', '', 'db_kasir');
                        $sql_kategori = "SELECT * FROM kategori";
                        $result_kategori = $conn->query($sql_kategori);
                        while ($kategori = $result_kategori->fetch_assoc()) {
                            // Set kategori yang dipilih berdasarkan produk yang sedang diedit
                            $selected = ($kategori['id_kategori'] == $row['id_kategori']) ? 'selected' : '';
                            echo "<option value='" . $kategori['id_kategori'] . "' $selected>" . $kategori['nama_kategori'] . "</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="harga" class="form-label">Harga</label>
                    <input type="number" class="form-control" name="harga" id="harga" value="<?php echo $row['harga']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="stok" class="form-label">Stok</label>
                    <input type="number" class="form-control" name="stok" id="stok" value="<?php echo $row['stok']; ?>" required>
                </div>

                <button type="submit" class="btn btn-primary">Update Produk</button>
                <a href="index.php?page=produk" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>

    <!-- Link ke Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
