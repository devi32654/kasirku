<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pelanggan
$pelanggan = $conn->query("SELECT * FROM pelanggan");

// Ambil data produk
$produk = $conn->query("SELECT * FROM produk");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pelanggan = $_POST['id_pelanggan'];
    $total_harga = 0;
    $tanggal_transaksi = date('Y-m-d H:i:s');
    $bayar = $_POST['bayar'];
    $kembalian = $bayar - $total_harga; // Hitung kembalian

    // Simpan transaksi (awalnya total_harga masih 0)
    $sql = "INSERT INTO transaksi (id_pelanggan, tanggal_transaksi, total_harga, bayar, kembalian) 
            VALUES ('$id_pelanggan', '$tanggal_transaksi', 0, '$bayar', '$kembalian')";
    $conn->query($sql);
    $id_transaksi = $conn->insert_id;

    // Simpan detail transaksi
    foreach ($_POST['produk'] as $key => $id_produk) {
        $jumlah = $_POST['jumlah'][$key];
        $harga = $_POST['harga'][$key];
        $sub_total = $jumlah * $harga;
        $total_harga += $sub_total;

        $sql = "INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah, sub_total) 
                VALUES ('$id_transaksi', '$id_produk', '$jumlah', '$sub_total')";
        $conn->query($sql);
    }

    // Update total transaksi, bayar, dan kembalian
    $kembalian = $bayar - $total_harga;
    $conn->query("UPDATE transaksi SET total_harga = '$total_harga', kembalian = '$kembalian' WHERE id_transaksi = '$id_transaksi'");

    header("Location: ?page=transaksi");
    exit();
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
    <!-- Link ke Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
        }

        .card {
            border: 1px solid #e1e4e8;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .table-bordered th, .table-bordered td {
            border: 1px solid #ddd;
        }

        .btn-custom {
            background-color: #28a745;
            border-color: #28a745;
            color: white;
        }

        .btn-custom:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .btn-danger-custom {
            background-color: #dc3545;
            border-color: #dc3545;
            color: white;
        }

        .btn-danger-custom:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }

        .btn-primary-custom {
            background-color: #007bff;
            border-color: #007bff;
            color: white;
        }

        .btn-primary-custom:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: bold;
        }

        .form-control[readonly] {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card p-4">
            <h1 class="mb-4">Tambah Transaksi</h1>
            <form action="" method="post" id="transaksi-form">

                <!-- Pilih Pelanggan -->
                <div class="mb-3">
                    <label for="id_pelanggan" class="form-label">Pilih Pelanggan:</label>
                    <select name="id_pelanggan" class="form-select" required>
                        <option value="">-- Pilih Pelanggan --</option>
                        <?php while ($row = $pelanggan->fetch_assoc()) { ?>
                            <option value="<?= $row['id_pelanggan'] ?>"><?= $row['nama_pelanggan'] ?></option>
                        <?php } ?>
                    </select>
                </div>

                <!-- Tabel Detail Transaksi -->
                <div class="mb-3">
                    <table class="table table-bordered table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Sub Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="detail-transaksi">
                            <tr>
                                <td>
                                    <select name="produk[]" class="form-select" required>
                                        <option value="">-- Pilih Produk --</option>
                                        <?php while ($row = $produk->fetch_assoc()) { ?>
                                            <option value="<?= $row['id_produk'] ?>" data-harga="<?= $row['harga'] ?>">
                                                <?= $row['nama_produk'] ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </td>
                                <td><input type="number" name="jumlah[]" class="form-control" required></td>
                                <td><input type="text" name="harga[]" class="form-control" readonly></td>
                                <td><input type="text" name="sub_total[]" class="form-control" readonly></td>
                                <td><button type="button" class="btn btn-danger-custom" onclick="hapusBaris(this)">Hapus</button></td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-primary-custom" onclick="tambahBaris()">Tambah Produk</button>
                </div>

                <!-- Total Harga -->
                <div class="mb-3">
                    <label for="total-harga" class="form-label">Total Harga:</label>
                    <input type="text" id="total-harga" name="total_harga" class="form-control" value="0" readonly>
                </div>

                <!-- Pembayaran -->
                <div class="mb-3">
                    <label for="bayar" class="form-label">Bayar:</label>
                    <input type="number" id="bayar" name="bayar" class="form-control" required><br><br>

                    <label for="kembalian" class="form-label">Kembalian:</label>
                    <input type="text" id="kembalian" class="form-control" readonly><br><br>
                </div>

                <button type="submit" class="btn btn-success" id="submit-button" disabled>Simpan Transaksi</button>
            </form>
        </div>
    </div>

    <!-- Link ke Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <script>
        function tambahBaris() {
            const row = document.querySelector('#detail-transaksi tr').cloneNode(true);
            document.querySelector('#detail-transaksi').appendChild(row);
            updateTotalHarga();
        }

        function hapusBaris(btn) {
            if (document.querySelectorAll('#detail-transaksi tr').length > 1) {
                btn.closest('tr').remove();
                updateTotalHarga();
            }
        }

        function updateTotalHarga() {
            let totalHarga = 0;
            document.querySelectorAll('#detail-transaksi tr').forEach(row => {
                const harga = row.querySelector('select[name="produk[]"]').selectedOptions[0].getAttribute('data-harga');
                const jumlah = row.querySelector('input[name="jumlah[]"]').value;
                const subTotal = harga * jumlah;
                row.querySelector('input[name="harga[]"]').value = harga;
                row.querySelector('input[name="sub_total[]"]').value = subTotal;
                totalHarga += subTotal;
            });

            document.getElementById('total-harga').value = totalHarga;
            checkBayar(totalHarga);
        }

        function checkBayar(totalHarga) {
            const bayar = document.getElementById('bayar').value;
            if (bayar >= totalHarga) {
                document.getElementById('submit-button').disabled = false;
                document.getElementById('kembalian').value = bayar - totalHarga;
            } else {
                document.getElementById('submit-button').disabled = true;
                document.getElementById('kembalian').value = 0;
            }
        }

        document.querySelector('#transaksi-form').addEventListener('input', function() {
            updateTotalHarga();
            const totalHarga = parseFloat(document.getElementById('total-harga').value);
            checkBayar(totalHarga);
        });
    </script>
</body>
</html>
