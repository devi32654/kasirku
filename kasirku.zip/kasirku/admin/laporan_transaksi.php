<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Filter tanggal (jika ada)
$filter = '';
if (isset($_POST['filter'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $filter = "WHERE t.tanggal_transaksi BETWEEN '$start_date' AND '$end_date'";
}

// Ambil data transaksi dengan detail produk
$sql = "
    SELECT t.id_transaksi, t.tanggal_transaksi, t.total_harga, t.bayar, t.kembalian, 
           p.nama_pelanggan, pr.nama_produk
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    JOIN detail_transaksi dt ON t.id_transaksi = dt.id_transaksi
    JOIN produk pr ON dt.id_produk = pr.id_produk
    $filter
    ORDER BY t.tanggal_transaksi DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none;
            }
        }
        
        body {
            background-color: #f8f9fa;
        }
        
        .card {
            border: 1px solid #e1e4e8;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        
        .table th, .table td {
            vertical-align: middle;
        }
        
        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        
        .btn-custom:hover {
            background-color: #0056b3;
        }
        
        .btn-print {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-print:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="card p-4">
            <h1 class="text-center mb-4">Laporan Transaksi</h1>

            <!-- Form Filter Tanggal -->
            <form method="POST" class="no-print mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <input type="date" name="start_date" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-md-4">
                        <input type="date" name="end_date" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" name="filter" class="btn btn-primary w-100">Filter</button>
                    </div>
                </div>
            </form>

            <!-- Tabel Laporan -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Tanggal Transaksi</th>
                            <th>Nama Pelanggan</th>
                            <th>Nama Produk</th>
                            <th>Total Harga</th>
                            <th>Total Bayar</th>
                            <th>Kembalian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $no = 1;
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . $no++ . "</td>
                                        <td>" . $row['tanggal_transaksi'] . "</td>
                                        <td>" . $row['nama_pelanggan'] . "</td>
                                        <td>" . $row['nama_produk'] . "</td>
                                        <td>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>
                                        <td>Rp " . number_format($row['bayar'], 0, ',', '.') . "</td>
                                        <td>Rp " . number_format($row['kembalian'], 0, ',', '.') . "</td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>Tidak ada data transaksi.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Tombol Cetak -->
            <div class="mt-3 text-end no-print">
            <a href="print_laporan_transaksi.php?start_date=<?php echo isset($start_date) ? $start_date : ''; ?>&end_date=<?php echo isset($end_date) ? $end_date : ''; ?>" 
   class="btn btn-print" target="_blank">
   Cetak
</a>


            </div>
        </div>
    </div>

    <!-- Link ke Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
