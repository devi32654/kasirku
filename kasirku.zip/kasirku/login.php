<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        /* Mengatur tampilan halaman */
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('kasir.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        /* Kontainer untuk form login */
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            width: 100%;
        }

        /* Kotak login */ 
        .login-box {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 380px;
            box-sizing: border-box;
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }

        /* Efek hover pada login box */
        .login-box:hover {
            transform: translateY(-10px);
        }

        /* Judul */
        h2 {
            font-weight: 500;
            margin-bottom: 25px;
            color: #333;
        }

        /* Label dan input */
        label {
            margin-top: 10px;
            display: block;
            padding-left: 10px;
            padding-right: 10px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        input::placeholder {
            color: #bbb;
        }

        input:focus {
            outline: none;
            border-color: #2F80ED;
        }

        /* Tombol login */
        button {
            width: 100%;
            padding: 12px;
            background-color: #2F80ED;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #56CCF2;
        }

        /* Pesan error */
        .error {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-bottom: 15px;
            font-weight: 500;
        }

        /* Link lupa password */
        .forgot-password {
            display: block;
            margin-top: 10px;
            text-decoration: none;
            color: #555;
            font-size: 14px;
        }

        .forgot-password:hover {
            color: #2F80ED;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Login Kasir</h2>
            <form method="POST" action="login.php">
                <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
                <input type="text" id="username" name="username" placeholder="Username" required>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
                <a href="forgot_password.php" class="forgot-password">Lupa password?</a>
            </form>
        </div>
    </div>
</body>
</html>
