<?php
session_start();
include('koneksi.php'); // Pastikan Anda sudah menyiapkan koneksi ke database

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Cek apakah username sudah terdaftar
    $check_query = "SELECT * FROM users WHERE username = '$username'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $error = "Username sudah terdaftar, coba username lain!";
    } else {
        // Query untuk menambahkan pengguna baru
        $insert_query = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
        if (mysqli_query($conn, $insert_query)) {
            // Jika berhasil, arahkan pengguna ke halaman login
            echo "<script>
                    alert('Registrasi berhasil, silakan login!');
                    window.location.href='login.php';
                  </script>";
        } else {
            $error = "Registrasi gagal. Terjadi kesalahan, coba lagi.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #56CCF2, #2F80ED);
        }

        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            width: 100%;
        }

        .register-box {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 380px;
            box-sizing: border-box;
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }

        /* Efek hover pada login box */
        .register-box:hover {
            transform: translateY(-10px);
        }

        h2 {
            font-weight: 500;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            margin-top: 10px;
            display: block;
            padding-left: 10px;
            padding-right: 10px;
            color: #555;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        input::placeholder {
            color: #bbb;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #2F80ED;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #2F80ED;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #56CCF2;
        }

        .error {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-bottom: 15px;
            font-weight: 500;
        }

        .login-link {
            display: block;
            margin-top: 15px;
            font-size: 14px;
            text-decoration: none;
            color: #555;
        }

        .login-link:hover {
            color: #2F80ED;
        }
    </style>
</head>
<body>

    <div class="register-container">
        <div class="register-box">
            <h2>Registrasi</h2>
            <form method="POST" action="register.php">
                <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

                <input type="text" id="username" name="username" placeholder="Username" required>

                <input type="password" id="password" name="password" placeholder="Password" required>

                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="petugas">Petugas</option>
                    <option value="admin">Admin</option>
                </select>

                <button type="submit" name="register">Daftar</button>

                <a href="login.php" class="login-link">Sudah punya akun? Login disini</a>
            </form>
        </div>
    </div>

</body>
</html>
